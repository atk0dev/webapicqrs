﻿namespace CustomerApi.Commands
{
    public abstract class Command
	{
		public long Id { get; set; }
	}
}
