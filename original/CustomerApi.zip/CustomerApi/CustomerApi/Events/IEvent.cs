﻿namespace CustomerApi.Events
{
	public interface IEvent
    {
    }
}
