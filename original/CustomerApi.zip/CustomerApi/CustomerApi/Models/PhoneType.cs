﻿namespace CustomerApi.Models
{
	public enum PhoneType
	{
			HOMEPHONE, CELLPHONE, WORKPHONE
	}
}
